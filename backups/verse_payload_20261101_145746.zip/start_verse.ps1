# Starts VERSE AI v11.0 Clean Professional SHIELD OS HUD
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
& (Join-Path $PSScriptRoot "stop_verse.ps1")
Start-Sleep -Milliseconds 300
python .\verse.py --serve
