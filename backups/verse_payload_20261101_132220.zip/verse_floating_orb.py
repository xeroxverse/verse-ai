#!/usr/bin/env python3
"""
VERSE Native Desktop Stark Arc Reactor Floating Orb (`verse_floating_orb.py`).
Renders an always-on-top, frameless, transparent Stark Arc Reactor HUD widget on Windows 11.
Features:
  - 10 Stator Coils + Counter-Rotating Degree Rings + Pulsing Arc Core
  - 6 Animation States: Idle, Listening, Thinking, Working, Speaking, Error
  - Background daemon thread polling (zero UI stutter, zero WinError 10053)
  - Drag anywhere on screen; Double-click to open JARVIS HUD (`http://127.0.0.1:8765`); Right-click to cycle states
"""

from __future__ import annotations
import json
import math
import threading
import time
import urllib.request
import webbrowser


STATE_PALETTES = {
    "Idle": ("#00f3ff", "#0088ff", "#ffaa00", 0.035),
    "Listening": ("#00ff9d", "#10b981", "#00f3ff", 0.085),
    "Thinking": ("#c084fc", "#9333ea", "#00f3ff", 0.140),
    "Working": ("#00f3ff", "#0284c7", "#ffaa00", 0.095),
    "Speaking": ("#38bdf8", "#00f3ff", "#ffaa00", 0.090),
    "Error": ("#ff2a54", "#dc2626", "#ffaa00", 0.120),
}


def launch_floating_orb(dashboard_url: str = "http://127.0.0.1:8765") -> int:
  try:
    import tkinter as tk
  except Exception as exc:
    print(f"[VERSE ORB] Tkinter GUI not available in headless environment: {exc}")
    return 0

  root = tk.Tk()
  root.title("J.A.R.V.I.S. Arc Reactor")
  root.geometry("156x176+48+48")
  root.overrideredirect(True)
  root.attributes("-topmost", True)

  bg_key = "#010203"
  root.configure(bg=bg_key)
  try:
    root.wm_attributes("-transparentcolor", bg_key)
  except Exception:
    pass

  canvas = tk.Canvas(
      root, width=156, height=176, bg=bg_key, highlightthickness=0
  )
  canvas.pack(fill="both", expand=True)

  state = {"mode": "Idle", "angle": 0.0, "drag_x": 0, "drag_y": 0}
  modes = list(STATE_PALETTES.keys())

  def on_press(event):
    state["drag_x"] = event.x
    state["drag_y"] = event.y

  def on_drag(event):
    x = root.winfo_x() + (event.x - state["drag_x"])
    y = root.winfo_y() + (event.y - state["drag_y"])
    root.geometry(f"+{x}+{y}")

  def on_double_click(event):
    webbrowser.open(dashboard_url)

  def on_right_click(event):
    idx = (modes.index(state["mode"]) + 1) % len(modes)
    state["mode"] = modes[idx]

  canvas.bind("<ButtonPress-1>", on_press)
  canvas.bind("<B1-Motion>", on_drag)
  canvas.bind("<Double-Button-1>", on_double_click)
  canvas.bind("<Button-3>", on_right_click)

  def _bg_poller():
    while True:
      try:
        req = urllib.request.Request(
            f"{dashboard_url}/api/orb-state", method="GET"
        )
        with urllib.request.urlopen(req, timeout=3.0) as resp:
          data = json.loads(resp.read().decode("utf-8"))
          if data.get("orb_state") in STATE_PALETTES:
            state["mode"] = data["orb_state"]
      except Exception:
        pass
      time.sleep(2.0)

  threading.Thread(target=_bg_poller, daemon=True).start()

  def animate():
    canvas.delete("all")
    core_col, ring_col, acc_col, speed = STATE_PALETTES.get(
        state["mode"], STATE_PALETTES["Idle"]
    )
    state["angle"] += speed
    cx, cy = 78, 76
    deg = int(math.degrees(state["angle"]) % 360)

    # 1. Outer 10 Stark Arc Reactor Stator Coils
    for i in range(10):
      start_deg = (i * 36 + deg) % 360
      canvas.create_arc(
          cx - 62,
          cy - 62,
          cx + 62,
          cy + 62,
          start=start_deg,
          extent=24,
          style="arc",
          outline=core_col,
          width=5,
      )

    # 2. Counter-rotating tactical gold/accent ring
    for offset in (0, 90, 180, 270):
      canvas.create_arc(
          cx - 48,
          cy - 48,
          cx + 48,
          cy + 48,
          start=(-deg * 2 + offset) % 360,
          extent=52,
          style="arc",
          outline=acc_col,
          width=2,
      )

    # 3. Inner high-speed turbine ring
    for offset in (30, 150, 270):
      canvas.create_arc(
          cx - 34,
          cy - 34,
          cx + 34,
          cy + 34,
          start=(deg * 3 + offset) % 360,
          extent=70,
          style="arc",
          outline=ring_col,
          width=2,
      )

    # 4. Pulsing Arc Reactor Core
    pulse = 16 + int(math.sin(state["angle"] * 2.5) * 4)
    canvas.create_oval(
        cx - pulse - 5,
        cy - pulse - 5,
        cx + pulse + 5,
        cy + pulse + 5,
        outline=core_col,
        width=1,
    )
    canvas.create_oval(
        cx - pulse,
        cy - pulse,
        cx + pulse,
        cy + pulse,
        fill=core_col,
        outline="#ffffff",
        width=2,
    )

    # 5. HUD Status Readout
    canvas.create_text(
        cx,
        158,
        text=f"J.A.R.V.I.S. // {state['mode'].upper()}",
        fill=core_col,
        font=("Consolas", 8, "bold"),
    )
    root.after(33, animate)

  animate()
  root.mainloop()
  return 0


if __name__ == "__main__":
  raise SystemExit(launch_floating_orb())
