"""
AI Model Management & Autonomous Task-to-Model Intent Router for Acer Swift Pro (Intel Core Ultra 5 125H).
Features:
  - Automatic Task-to-Model Selection (`auto_select_model_for_task`): analyzes user prompt and automatically picks
    the right specialist model (Coding, UI/Web, Reasoning/Security, Fast Conversation, or NPU Embeddings)
  - Enforces Hardware Overload Circuit Breaker: automatically steps down model size if RAM usage >= 80%
  - Sequential single-model loading & automatic RAM purge after completion
"""

from __future__ import annotations
import json
from pathlib import Path
import socket
import time
from typing import Any, Dict, List
import urllib.request

from .config import VerseConfig
from .hardware import HardwareMonitor


class ModelManager:

  def __init__(self, config: VerseConfig, hardware: HardwareMonitor):
    self.config = config
    self.hardware = hardware
    self.registry_path = self.config.configs_dir / "models_registry.json"
    self._port_cache: dict[int, tuple[float, bool]] = {}
    self._last_auto_route: Dict[str, Any] = {
        "task_category": "general_orchestration",
        "selected_model": self.config.default_fast_model,
        "primary_agent": "CEO_AI",
        "reason": "Initial standby state",
    }
    self._init_registry()

  def _is_local_port_open(self, port: int) -> bool:
    now = time.monotonic()
    cached = self._port_cache.get(port)
    if cached and (now - cached[0]) < 15.0:
      return cached[1]
    try:
      with socket.create_connection(("127.0.0.1", port), timeout=0.12):
        self._port_cache[port] = (now, True)
        return True
    except Exception:
      self._port_cache[port] = (now, False)
      return False

  def _init_registry(self) -> None:
    if not self.registry_path.exists():
      default_reg = {
          "active_loaded_model": "none",
          "auto_routing_enabled": True,
          "role_assignments": {
              "CEO_AI": self.config.default_fast_model,
              "RESEARCH_AI": self.config.default_fast_model,
              "DESIGNER_AI": self.config.default_coder_model,
              "CODER_AI": self.config.default_coder_model,
              "TESTER_AI": self.config.default_fast_model,
              "SECURITY_AI": self.config.default_fast_model,
              "VOICE_AI": self.config.default_fast_model,
              "EMPLOYEE_AI": self.config.default_fast_model,
          },
          "registered_gguf_models": [
              {
                  "name": "qwen2.5-1.5b-instruct-q4_k_m.gguf",
                  "specialty": "Fast Planning, Hindi/English Chat & Voice",
                  "quantization": "Q4_K_M",
                  "est_ram_gb": 1.2,
                  "compatible_ultra5_125h": True,
                  "path": str(
                      self.config.models_dir
                      / "qwen2.5-1.5b-instruct-q4_k_m.gguf"
                  ),
              },
              {
                  "name": "qwen2.5-coder-3b-instruct-q4_k_m.gguf",
                  "specialty": "Websites, UI/UX, Python APIs & Fast Coding",
                  "quantization": "Q4_K_M",
                  "est_ram_gb": 2.3,
                  "compatible_ultra5_125h": True,
                  "path": str(
                      self.config.models_dir
                      / "qwen2.5-coder-3b-instruct-q4_k_m.gguf"
                  ),
              },
              {
                  "name": "qwen2.5-coder-7b-instruct-q4_k_m.gguf",
                  "specialty": "Heavy Full-Stack & Android Architecture (Requires >=7GB Free RAM)",
                  "quantization": "Q4_K_M",
                  "est_ram_gb": 4.6,
                  "compatible_ultra5_125h": True,
                  "path": str(
                      self.config.models_dir
                      / "qwen2.5-coder-7b-instruct-q4_k_m.gguf"
                  ),
              },
          ],
      }
      self.registry_path.write_text(
          json.dumps(default_reg, indent=2), encoding="utf-8"
      )

  def auto_select_model_for_task(self, user_prompt: str) -> Dict[str, Any]:
    """
    Automatically determines from the user's prompt which AI model and specialist agent
    should handle the work, while checking the Laptop Overload Circuit Breaker first.
    """
    text = (user_prompt or "").lower()
    guard = self.hardware.check_overload_guard()
    ram = self.hardware.get_ram_telemetry()

    if guard["circuit_breaker_tripped"]:
      route = {
          "task_category": "overload_protected_safe_mode",
          "selected_model": "qwen2.5:0.5b-instruct-q4_K_M",
          "primary_agent": "CEO_AI",
          "estimated_ram_gb": 0.5,
          "reason": (
              "Overload Guard active: auto-selected ultra-light 0.5B model to"
              " protect laptop RAM/CPU."
          ),
      }
      self._last_auto_route = route
      return route

    # 1. Heavy Software / Full-Stack / Android / Complex Code
    if any(
        k in text
        for k in [
            "android",
            "flutter",
            "full-stack",
            "fullstack",
            "database",
            "backend",
            "api",
            "python",
            "automation",
            "debug",
            "script",
        ]
    ):
      chosen = (
          self.config.heavy_coder_model
          if ram["available_gb"] >= 7.5
          else self.config.default_coder_model
      )
      est_ram = 4.6 if "7b" in chosen else 2.3
      route = {
          "task_category": "software_and_api_engineering",
          "selected_model": chosen,
          "primary_agent": "CODER_AI",
          "estimated_ram_gb": est_ram,
          "reason": (
              f"Detected software/API engineering task -> Auto-routed to {chosen}"
              f" ({est_ram} GB RAM, safe for 16GB Ultra 5)."
          ),
      }
    # 2. Website / UI/UX / E-Commerce / Frontend
    elif any(
        k in text
        for k in [
            "website",
            "web",
            "ui",
            "ux",
            "design",
            "html",
            "css",
            "portfolio",
            "ecommerce",
            "landing",
            "jarvis",
        ]
    ):
      route = {
          "task_category": "web_and_ui_design",
          "selected_model": self.config.default_coder_model,
          "primary_agent": "DESIGNER_AI + CODER_AI",
          "estimated_ram_gb": 2.3,
          "reason": (
              "Detected Website/UI task -> Auto-routed to"
              f" {self.config.default_coder_model} (2.3 GB RAM) for fast"
              " HTML/CSS/JS generation."
          ),
      }
    # 3. Security Audit / Research / Architecture Analysis
    elif any(
        k in text
        for k in [
            "security",
            "audit",
            "vulnerability",
            "research",
            "compare",
            "analyse",
            "analyze",
        ]
    ):
      route = {
          "task_category": "research_and_security_audit",
          "selected_model": "deepseek-r1:1.5b-q4_K_M",
          "primary_agent": "RESEARCH_AI + SECURITY_AI",
          "estimated_ram_gb": 1.3,
          "reason": (
              "Detected Research/Security task -> Auto-routed to"
              " deepseek-r1:1.5b-q4_K_M (1.3 GB RAM)."
          ),
      }
    # 4. Default Fast Conversation / Planning / Voice
    else:
      route = {
          "task_category": "fast_planning_and_conversation",
          "selected_model": self.config.default_fast_model,
          "primary_agent": "CEO_AI + VOICE_AI",
          "estimated_ram_gb": 1.2,
          "reason": (
              "Detected general/planning directive -> Auto-routed to"
              f" lightweight {self.config.default_fast_model} (1.2 GB RAM)."
          ),
      }

    self._last_auto_route = route
    # Automatically update CODER_AI / active role assignment
    self.assign_role_model("CODER_AI", route["selected_model"])
    return route

  def scan_local_gguf_files(self) -> List[Dict[str, Any]]:
    found: List[Dict[str, Any]] = []
    search_dirs = [
        self.config.models_dir,
        Path.home() / ".cache" / "lm-studio" / "models",
        Path.home() / "models",
    ]
    for d in search_dirs:
      if d.exists() and d.is_dir():
        for f in d.rglob("*.gguf"):
          try:
            size_gb = round(f.stat().st_size / (1024**3), 2)
            found.append({
                "name": f.name,
                "path": str(f),
                "size_gb": size_gb,
                "fits_16gb_ram": (
                    size_gb <= self.config.hardware.max_single_model_ram_gb
                ),
            })
          except Exception:
            pass
    return found

  def check_server_health(self) -> Dict[str, Any]:
    ollama_ok = False
    ollama_models: List[str] = []
    if self._is_local_port_open(11434):
      try:
        req = urllib.request.Request(
            f"{self.config.ollama_base_url}/api/tags", method="GET"
        )
        with urllib.request.urlopen(req, timeout=0.2) as resp:
          body = json.loads(resp.read().decode("utf-8"))
          ollama_models = [m.get("name", "") for m in body.get("models", [])]
          ollama_ok = True
      except Exception:
        ollama_ok = False

    llamacpp_ok = False
    if self._is_local_port_open(8080):
      try:
        req = urllib.request.Request(
            f"{self.config.llamacpp_base_url}/health", method="GET"
        )
        with urllib.request.urlopen(req, timeout=0.2) as resp:
          llamacpp_ok = resp.status == 200
      except Exception:
        llamacpp_ok = False

    reg = json.loads(self.registry_path.read_text(encoding="utf-8"))
    return {
        "ollama_online": ollama_ok,
        "ollama_installed_models": ollama_models,
        "llamacpp_online": llamacpp_ok,
        "local_gguf_files_detected": self.scan_local_gguf_files(),
        "active_loaded_model": reg.get("active_loaded_model", "none"),
        "auto_routing_enabled": reg.get("auto_routing_enabled", True),
        "last_auto_route": self._last_auto_route,
        "role_assignments": reg.get("role_assignments", {}),
        "registered_gguf_models": reg.get("registered_gguf_models", []),
        "fallback_engine": (
            "VERSE_LOCAL_STRUCTURED_ENGINE (Zero-Cost Offline Ready)"
        ),
    }

  def register_gguf_model(
      self, name: str, path: str, est_ram_gb: float = 2.5
  ) -> Dict[str, Any]:
    reg = json.loads(self.registry_path.read_text(encoding="utf-8"))
    models = reg.setdefault("registered_gguf_models", [])
    compatible = est_ram_gb <= self.config.hardware.max_single_model_ram_gb
    entry = {
        "name": name,
        "quantization": "GGUF",
        "est_ram_gb": est_ram_gb,
        "compatible_ultra5_125h": compatible,
        "path": path,
    }
    models.append(entry)
    self.registry_path.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    return entry

  def assign_role_model(self, role: str, model_name: str) -> Dict[str, Any]:
    reg = json.loads(self.registry_path.read_text(encoding="utf-8"))
    reg.setdefault("role_assignments", {})[role] = model_name
    self.registry_path.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    return reg["role_assignments"]

  def load_model_for_role(self, role: str) -> str:
    reg = json.loads(self.registry_path.read_text(encoding="utf-8"))
    ram = self.hardware.get_ram_telemetry()
    chosen = reg.get("role_assignments", {}).get(
        role, self.config.default_fast_model
    )
    if ram["available_gb"] < 3.5 and "7b" in chosen.lower():
      chosen = self.config.default_fast_model
    actual = self.hardware.acquire_model(chosen)
    reg["active_loaded_model"] = actual
    self.registry_path.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    return actual

  def unload_active_model(self) -> Dict[str, str]:
    self.hardware.release_model()
    reg = json.loads(self.registry_path.read_text(encoding="utf-8"))
    reg["active_loaded_model"] = "none"
    self.registry_path.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    return {"status": "UNLOADED", "active_loaded_model": "none"}

  def infer(
      self, role: str, prompt: str, system_prompt: str = "You are VERSE AI."
  ) -> Dict[str, Any]:
    model = self.load_model_for_role(role)

    if self._is_local_port_open(11434):
      try:
        payload = json.dumps({
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            "stream": False,
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{self.config.ollama_base_url}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=0.25) as resp:
          data = json.loads(resp.read().decode("utf-8"))
          content = data.get("message", {}).get("content")
          if content:
            return {
                "provider": "ollama_local",
                "model": model,
                "output": content,
            }
      except Exception:
        pass

    if self._is_local_port_open(8080):
      try:
        payload = json.dumps({
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{self.config.llamacpp_base_url}/v1/chat/completions",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=0.25) as resp:
          data = json.loads(resp.read().decode("utf-8"))
          choices = data.get("choices", [])
          if choices:
            return {
                "provider": "llamacpp_local",
                "model": model,
                "output": choices[0].get("message", {}).get("content", ""),
            }
      except Exception:
        pass

    return {
        "provider": "verse_local_synthesis",
        "model": model,
        "output": f"[{role}] Processed directive: {prompt[:200]}",
    }
