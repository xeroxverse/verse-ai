# Starts VERSE AI v8.5 Hyper-Animated SHIELD OS HUD + Floating AI Orb with Cache Busting
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
& (Join-Path $PSScriptRoot "stop_verse.ps1")
Start-Sleep -Milliseconds 400
python .\verse.py --orb
