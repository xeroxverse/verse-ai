#!/usr/bin/env python3
"""
VERSE AI — Native Desktop Floating Command Dock & Reactor Orb (`verse_floating_orb.py`).
Strictly branded VERSE AI (Zero "JARVIS" references).
Features:
  - Always-on-top, frameless desktop mini-HUD (`VERSE AI // <STATE>`)
  - Live RAM % & Overload Shield Telemetry readout
  - Interactive Quick Command Input + 4 Action Buttons right on the desktop:
      1. [🎤 HELLO VERSE] — Triggers Wake Greeting & Voice Activation
      2. [⚡ FREE RAM]    — Purges active model RAM immediately
      3. [🖥 FULL HUD]    — Opens the full SHIELD OS Web HUD (`http://127.0.0.1:8765`)
      4. [▶ SEND]         — Executes any typed command directly from the floating orb
  - Background daemon thread polling (zero UI stutter, zero WinError 10053)
"""

from __future__ import annotations
import json
import math
import threading
import time
import urllib.request
import webbrowser


STATE_PALETTES = {
    "Idle": ("#00f3ff", "#0088ff", "#ffaa00", 0.040),
    "Listening": ("#00ff9d", "#10b981", "#00f3ff", 0.095),
    "Thinking": ("#c084fc", "#9333ea", "#00f3ff", 0.140),
    "Working": ("#00f3ff", "#0284c7", "#ffaa00", 0.105),
    "Speaking": ("#38bdf8", "#00f3ff", "#ffaa00", 0.095),
    "Error": ("#ff2a54", "#dc2626", "#ffaa00", 0.120),
}


def launch_floating_orb(dashboard_url: str = "http://127.0.0.1:8765") -> int:
    try:
        import tkinter as tk
    except Exception as exc:
        print(f"[VERSE AI ORB] Tkinter GUI not available in headless environment: {exc}")
        return 0

    root = tk.Tk()
    root.title("VERSE AI — Desktop Command Orb")
    root.geometry("220x252+36+36")
    root.overrideredirect(True)
    root.attributes("-topmost", True)

    bg_panel = "#060b14"
    root.configure(bg=bg_panel, highlightbackground="#00e5ff", highlightthickness=1)

    state = {
        "mode": "Idle",
        "angle": 0.0,
        "drag_x": 0,
        "drag_y": 0,
        "ram_pct": 0.0,
        "voice_name": "Makoto Tensei",
        "status_line": "Say 'Hello VERSE' or type below",
    }
    modes = list(STATE_PALETTES.keys())

    # Top Reactor Canvas
    canvas = tk.Canvas(
        root, width=218, height=154, bg=bg_panel, highlightthickness=0
    )
    canvas.pack(fill="x", side="top")

    def on_press(event):
        state["drag_x"] = event.x
        state["drag_y"] = event.y

    def on_drag(event):
        x = root.winfo_x() + (event.x - state["drag_x"])
        y = root.winfo_y() + (event.y - state["drag_y"])
        root.geometry(f"+{x}+{y}")

    def on_double_click(event):
        webbrowser.open(f"{dashboard_url}/?v=verse_orb_{int(time.time())}")

    def on_right_click(event):
        idx = (modes.index(state["mode"]) + 1) % len(modes)
        state["mode"] = modes[idx]

    canvas.bind("<ButtonPress-1>", on_press)
    canvas.bind("<B1-Motion>", on_drag)
    canvas.bind("<Double-Button-1>", on_double_click)
    canvas.bind("<Button-3>", on_right_click)

    # Interactive Controls Frame inside the Floating Orb
    ctrl_frame = tk.Frame(root, bg=bg_panel, padx=6, pady=2)
    ctrl_frame.pack(fill="both", expand=True)

    entry_frame = tk.Frame(ctrl_frame, bg=bg_panel)
    entry_frame.pack(fill="x", pady=(0, 4))

    cmd_entry = tk.Entry(
        entry_frame,
        bg="#0d1829",
        fg="#eef8fc",
        insertbackground="#00e5ff",
        relief="flat",
        font=("Consolas", 8),
         highlightthickness=1,
        highlightbackground="#00e5ff",
    )
    cmd_entry.pack(side="left", fill="x", expand=True, ipady=3, padx=(0, 4))
    cmd_entry.insert(0, "Hello VERSE")

    def _post_api(path: str, payload: dict) -> dict:
        req = urllib.request.Request(
            f"{dashboard_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=25.0) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def run_orb_command(custom_msg: str | None = None):
        msg = (custom_msg if custom_msg is not None else cmd_entry.get()).strip()
        if not msg:
            return
        if custom_msg is None:
            cmd_entry.delete(0, tk.END)
        state["mode"] = "Working"
        state["status_line"] = f"Running: {msg[:24]}..."

        def _worker():
            try:
                res = _post_api("/api/chat", {"message": msg, "speak_aloud": True})
                spoken = (
                    res.get("voice_report", {}).get("spoken_text")
                    or res.get("ceo_review", {}).get("ceo_summary")
                    or "Confirmed. Task complete."
                )
                state["status_line"] = spoken[:34]
                state["mode"] = "Speaking"
                time.sleep(1.5)
                state["mode"] = "Idle"
            except Exception:
                state["status_line"] = "HUD Ready — Click Open HUD"
                state["mode"] = "Idle"

        threading.Thread(target=_worker, daemon=True).start()

    cmd_entry.bind("<Return>", lambda _e: run_orb_command())

    send_btn = tk.Button(
        entry_frame,
        text="RUN",
        command=run_orb_command,
        bg="#00e5ff",
        fg="#040810",
        activebackground="#00ff9d",
        relief="flat",
        font=("Consolas", 8, "bold"),
        padx=6,
        cursor="hand2",
    )
    send_btn.pack(side="right")

    # 3 Quick Action Buttons Row
    btn_row = tk.Frame(ctrl_frame, bg=bg_panel)
    btn_row.pack(fill="x", pady=(2, 2))

    def wake_verse():
        run_orb_command("Hello VERSE")

    def purge_ram():
        state["status_line"] = "Purging model RAM..."

        def _p():
            try:
                _post_api("/api/models/unload", {})
                state["status_line"] = "RAM Purged (<80% Safe)"
            except Exception:
                state["status_line"] = "RAM Shield Active"

        threading.Thread(target=_p, daemon=True).start()

    def open_hud():
        webbrowser.open(f"{dashboard_url}/?v=verse_orb_{int(time.time())}")

    tk.Button(
        btn_row,
        text="🎤 WAKE",
        command=wake_verse,
        bg="#102338",
        fg="#00ff9d",
        relief="flat",
        font=("Consolas", 7, "bold"),
        cursor="hand2",
    ).pack(side="left", expand=True, fill="x", padx=(0, 2))

    tk.Button(
        btn_row,
        text="⚡ RAM",
        command=purge_ram,
        bg="#102338",
        fg="#ffaa00",
        relief="flat",
        font=("Consolas", 7, "bold"),
        cursor="hand2",
    ).pack(side="left", expand=True, fill="x", padx=2)

    tk.Button(
        btn_row,
        text="🖥 HUD",
        command=open_hud,
        bg="#102338",
        fg="#00e5ff",
        relief="flat",
        font=("Consolas", 7, "bold"),
        cursor="hand2",
    ).pack(side="left", expand=True, fill="x", padx=(2, 0))

    def _bg_poller():
        while True:
            try:
                req = urllib.request.Request(
                    f"{dashboard_url}/api/status", method="GET"
                )
                with urllib.request.urlopen(req, timeout=3.0) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    orb_st = data.get("orb_state", "Idle")
                    if orb_st in STATE_PALETTES:
                        state["mode"] = orb_st
                    ram_pct = (
                        data.get("hardware", {})
                        .get("ram", {})
                        .get("percent_used", 0.0)
                    )
                    if ram_pct:
                        state["ram_pct"] = ram_pct
            except Exception:
                pass
            time.sleep(2.5)

    threading.Thread(target=_bg_poller, daemon=True).start()

    def animate():
        canvas.delete("all")
        core_col, ring_col, acc_col, speed = STATE_PALETTES.get(
            state["mode"], STATE_PALETTES["Idle"]
        )
        state["angle"] += speed
        cx, cy = 109, 64
        deg = int(math.degrees(state["angle"]) % 360)

        # 1. Outer 10 VERSE AI Reactor Coils
        for i in range(10):
            start_deg = (i * 36 + deg) % 360
            canvas.create_arc(
                cx - 48,
                cy - 48,
                cx + 48,
                cy + 48,
                start=start_deg,
                extent=24,
                style="arc",
                outline=core_col,
                width=4,
            )

        # 2. Counter-rotating tactical gold/accent ring
        for offset in (0, 90, 180, 270):
            canvas.create_arc(
                cx - 37,
                cy - 37,
                cx + 37,
                cy + 37,
                start=(-deg * 2 + offset) % 360,
                extent=52,
                style="arc",
                outline=acc_col,
                width=2,
            )

        # 3. Inner high-speed turbine ring
        for offset in (30, 150, 270):
            canvas.create_arc(
                cx - 26,
                cy - 26,
                cx + 26,
                cy + 26,
                start=(deg * 3 + offset) % 360,
                extent=70,
                style="arc",
                outline=ring_col,
                width=2,
            )

        # 4. Pulsing VERSE AI Core
        pulse = 12 + int(math.sin(state["angle"] * 2.5) * 3)
        canvas.create_oval(
            cx - pulse - 4,
            cy - pulse - 4,
            cx + pulse + 4,
            cy + pulse + 4,
            outline=core_col,
            width=1,
        )
        canvas.create_oval(
            cx - pulse,
            cy - pulse,
            cx + pulse,
            cy + pulse,
            fill=core_col,
            outline="#ffffff",
            width=2,
        )

        # 5. Strictly Branded VERSE AI Status Readout + Live RAM Telemetry
        ram_str = f" | RAM {int(state['ram_pct'])}%" if state["ram_pct"] else ""
        canvas.create_text(
            cx,
            124,
            text=f"VERSE AI // {state['mode'].upper()}{ram_str}",
            fill=core_col,
            font=("Consolas", 8, "bold"),
        )
        canvas.create_text(
            cx,
            140,
            text=state["status_line"][:32],
            fill="#9cb4c9",
            font=("Consolas", 7),
        )
        root.after(33, animate)

    animate()
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(launch_floating_orb())
