# Gracefully stops running VERSE Python processes listening on port 8765
Get-NetTCPConnection -LocalPort 8765 -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue
}
Write-Host "[VERSE] Stopped VERSE HUD server cleanly." -ForegroundColor Green
