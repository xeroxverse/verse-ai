# Starts VERSE Master AI Orchestrator HUD + Floating AI Orb
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
Start-Process "http://127.0.0.1:8765"
python .\verse.py --orb
