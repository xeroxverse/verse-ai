#!/usr/bin/env python3
"""
VERSE Native Desktop Floating AI Orb (`verse_floating_orb.py`).
Renders an always-on-top, frameless, transparent circular glowing energy orb on Windows 11.
Features:
  - 6 Animation States: Idle, Listening, Thinking, Working, Speaking, Error
  - Drag anywhere on screen
  - Double-click to open the main JARVIS HUD Dashboard in browser (`http://127.0.0.1:8765`)
  - Right-click to cycle states or exit cleanly
"""

from __future__ import annotations
import json
import math
import urllib.request
import webbrowser


STATE_PALETTES = {
    "Idle": ("#00f0ff", "#38bdf8", 0.04),
    "Listening": ("#10b981", "#34d399", 0.09),
    "Thinking": ("#a855f7", "#c084fc", 0.16),
    "Working": ("#00f0ff", "#0284c7", 0.11),
    "Speaking": ("#22d3ee", "#67e8f9", 0.10),
    "Error": ("#ef4444", "#f87171", 0.12),
}


def launch_floating_orb(dashboard_url: str = "http://127.0.0.1:8765") -> int:
  try:
    import tkinter as tk
  except Exception as exc:
    print(f"[VERSE ORB] Tkinter GUI not available in headless environment: {exc}")
    return 0

  root = tk.Tk()
  root.title("VERSE AI Orb")
  root.geometry("130x150+60+60")
  root.overrideredirect(True)
  root.attributes("-topmost", True)

  bg_key = "#010203"
  root.configure(bg=bg_key)
  try:
    root.wm_attributes("-transparentcolor", bg_key)
  except Exception:
    pass

  canvas = tk.Canvas(
      root, width=130, height=150, bg=bg_key, highlightthickness=0
  )
  canvas.pack(fill="both", expand=True)

  state = {"mode": "Idle", "angle": 0.0, "drag_x": 0, "drag_y": 0}
  modes = list(STATE_PALETTES.keys())

  def on_press(event):
    state["drag_x"] = event.x
    state["drag_y"] = event.y

  def on_drag(event):
    x = root.winfo_x() + (event.x - state["drag_x"])
    y = root.winfo_y() + (event.y - state["drag_y"])
    root.geometry(f"+{x}+{y}")

  def on_double_click(event):
    webbrowser.open(dashboard_url)

  def on_right_click(event):
    idx = (modes.index(state["mode"]) + 1) % len(modes)
    state["mode"] = modes[idx]

  canvas.bind("<ButtonPress-1>", on_press)
  canvas.bind("<B1-Motion>", on_drag)
  canvas.bind("<Double-Button-1>", on_double_click)
  canvas.bind("<Button-3>", on_right_click)

  def poll_backend():
    try:
      req = urllib.request.Request(f"{dashboard_url}/api/orb-state", method="GET")
      with urllib.request.urlopen(req, timeout=0.4) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        if data.get("orb_state") in STATE_PALETTES:
          state["mode"] = data["orb_state"]
    except Exception:
      pass
    root.after(1500, poll_backend)

  def animate():
    canvas.delete("all")
    core_col, ring_col, speed = STATE_PALETTES.get(
        state["mode"], STATE_PALETTES["Idle"]
    )
    state["angle"] += speed
    cx, cy = 65, 65

    # Outer rotating energy arcs
    deg = int(math.degrees(state["angle"]) % 360)
    for offset in (0, 120, 240):
      canvas.create_arc(
          cx - 46,
          cy - 46,
          cx + 46,
          cy + 46,
          start=(deg + offset) % 360,
          extent=68,
          style="arc",
          outline=ring_col,
          width=3,
      )

    # Inner counter-rotating energy arcs
    for offset in (45, 225):
      canvas.create_arc(
          cx - 32,
          cy - 32,
          cx + 32,
          cy + 32,
          start=(-deg * 2 + offset) % 360,
          extent=85,
          style="arc",
          outline=core_col,
          width=2,
      )

    # Pulsing centre core
    pulse = 14 + int(math.sin(state["angle"] * 2.5) * 4)
    canvas.create_oval(
        cx - pulse,
        cy - pulse,
        cx + pulse,
        cy + pulse,
        fill=core_col,
        outline="#ffffff",
        width=1,
    )

    # Label pill
    canvas.create_text(
        cx,
        134,
        text=f"VERSE • {state['mode'].upper()}",
        fill=core_col,
        font=("Segoe UI", 8, "bold"),
    )
    root.after(33, animate)

  poll_backend()
  animate()
  root.mainloop()
  return 0


if __name__ == "__main__":
  raise SystemExit(launch_floating_orb())
