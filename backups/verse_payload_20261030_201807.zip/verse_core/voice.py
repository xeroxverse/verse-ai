"""
Bilingual Voice Assistant System (Hindi hi-IN + English en-IN/en-US).
Supports:
  - Native Windows 11 TTS via `System.Speech.Synthesis.SpeechSynthesizer` (zero extra pip deps required)
  - Browser Web Speech API (`window.speechSynthesis` & `webkitSpeechRecognition`) in JARVIS UI
  - Push-to-Talk & Microphone Permission Diagnostics
  - Honest reporting of wake-word vs push-to-talk capabilities
"""

from __future__ import annotations
import platform
import subprocess
from typing import Any, Dict


class VoiceAssistant:

  def __init__(self):
    self.supported_languages = ["en-IN", "hi-IN", "en-US"]
    self.active_language = "hi-IN"
    self.tts_enabled = True
    self.push_to_talk_ready = True
    self.wake_word_status = (
        "OPTIONAL_PLUGIN_NOT_LOADED (Use Push-to-Talk button or Alt+V shortcut)"
    )

  def detect_language(self, text: str) -> str:
    """Detects Hindi (Devanagari or common Hinglish markers) vs English."""
    for ch in text:
      if "\u0900" <= ch <= "\u097f":
        return "hi-IN"
    hinglish_tokens = {
        "mujhe",
        "banani",
        "banao",
        "karo",
        "kya",
        "hai",
        "mera",
        "ek",
        "chahiye",
        "dikhao",
    }
    words = {w.strip(".,!?").lower() for w in text.split()}
    if words.intersection(hinglish_tokens):
      return "hi-IN"
    return "en-IN"

  def speak(
      self, text: str, language: str | None = None, dry_run: bool = False
  ) -> Dict[str, Any]:
    """Speaks text aloud on Windows 11 via PowerShell System.Speech or returns speech payload for Web UI TTS."""
    lang = language or self.detect_language(text)
    clean_text = (
        (text or "").replace('"', "'").replace("\n", " ").strip()[:320]
    )

    if dry_run or platform.system() != "Windows":
      return {
          "status": "SYNTHESIZED_FOR_WEB_AUDIO",
          "engine": "browser_web_speech_api",
          "language": lang,
          "spoken_text": clean_text,
      }

    ps_cmd = (
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f'$s.Speak("{clean_text}");'
    )
    try:
      subprocess.Popen(
          [
              "powershell",
              "-NoProfile",
              "-WindowStyle",
              "Hidden",
              "-Command",
              ps_cmd,
          ],
          stdout=subprocess.DEVNULL,
          stderr=subprocess.DEVNULL,
      )
      return {
          "status": "SPEAKING_NATIVE_WINDOWS",
          "engine": "windows_sapi_speech",
          "language": lang,
          "spoken_text": clean_text,
      }
    except Exception as exc:
      return {
          "status": "FALLBACK_WEB_AUDIO",
          "engine": "browser_web_speech_api",
          "language": lang,
          "spoken_text": clean_text,
          "error": str(exc),
      }

  def status(self) -> Dict[str, Any]:
    return {
        "tts_ready": True,
        "stt_ready_in_dashboard": True,
        "supported_languages": self.supported_languages,
        "active_language": self.active_language,
        "push_to_talk": "READY (Click Mic Icon or press Alt+V)",
        "wake_word": self.wake_word_status,
        "native_windows_sapi": platform.system() == "Windows",
    }
